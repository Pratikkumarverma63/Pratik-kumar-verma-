import { notFound } from "next/navigation";
import Link from "next/link";
import { getPostBySlug, getAllPosts } from "@/lib/queries";

export async function generateStaticParams() {
  return getAllPosts().map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) return {};
  return {
    title: post.title,
    description: post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: { title: post.title, description: post.excerpt, type: "article" },
  };
}

export default async function BlogPostPage({ params }) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  if (!post) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.excerpt,
    datePublished: post.published_at,
    author: { "@type": "Organization", name: "Roamfare" },
  };

  const paragraphs = post.content.split("\n\n");

  return (
    <article className="mx-auto max-w-2xl px-5 sm:px-8 pt-14 pb-24">
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <Link href="/blog" className="font-mono text-xs text-airmail-blue hover:underline">
        ← Field Notes
      </Link>
      <div className="text-4xl mt-6 mb-4">{post.cover_emoji}</div>
      <p className="font-mono text-[11px] uppercase tracking-wide text-airmail-blue mb-3">
        {post.category} · {post.read_minutes} min read
      </p>
      <h1 className="font-display text-3xl sm:text-4xl leading-tight mb-8">{post.title}</h1>
      <div className="prose-content space-y-5 text-[15px] leading-relaxed text-ink">
        {paragraphs.map((p, i) => {
          if (p.startsWith("**") && p.endsWith("**") && !p.slice(2).includes("**")) {
            return (
              <h2 key={i} className="font-display text-xl mt-8 mb-2">
                {p.replaceAll("**", "")}
              </h2>
            );
          }
          if (/^\d\. /.test(p) || p.startsWith("- ")) {
            const items = p.split("\n").filter(Boolean);
            return (
              <ul key={i} className="list-disc pl-5 space-y-1">
                {items.map((it, j) => (
                  <li key={j}>{it.replace(/^(-|\d\.)\s*/, "")}</li>
                ))}
              </ul>
            );
          }
          return <p key={i}>{p}</p>;
        })}
      </div>
    </article>
  );
}
