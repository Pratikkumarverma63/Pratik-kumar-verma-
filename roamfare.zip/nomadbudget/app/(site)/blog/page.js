import Link from "next/link";
import { getAllPosts } from "@/lib/queries";

export const metadata = {
  title: "Field Notes",
  description:
    "Practical, unglamorous writing on budget travel, slow travel, and working remotely abroad.",
  alternates: { canonical: "/blog" },
};

export default function BlogPage() {
  const posts = getAllPosts();

  return (
    <section className="mx-auto max-w-6xl px-5 sm:px-8 pt-14 pb-20">
      <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-3">
        Dispatches
      </p>
      <h1 className="font-display text-3xl sm:text-4xl mb-10">Field Notes</h1>

      <div className="grid md:grid-cols-2 gap-6">
        {posts.map((p) => (
          <Link
            key={p.id}
            href={`/blog/${p.slug}`}
            className="group block bg-paper-raised border border-ink/10 rounded-2xl p-6 hover:border-ink/30 transition-colors focus-ring"
          >
            <div className="text-3xl mb-4">{p.cover_emoji}</div>
            <p className="font-mono text-[11px] uppercase tracking-wide text-airmail-blue mb-2">
              {p.category} · {p.read_minutes} min read
            </p>
            <h2 className="font-display text-xl leading-snug mb-2 group-hover:underline">
              {p.title}
            </h2>
            <p className="text-sm text-ink-soft">{p.excerpt}</p>
          </Link>
        ))}
      </div>
    </section>
  );
}
