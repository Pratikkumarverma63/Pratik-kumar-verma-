import ContactForm from "@/components/ContactForm";

export const metadata = {
  title: "Contact",
  description: "Questions about a course or a partnership? Get in touch with Roamfare.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <section className="mx-auto max-w-lg px-5 sm:px-8 pt-14 pb-24">
      <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-3">
        Get in touch
      </p>
      <h1 className="font-display text-3xl mb-3">Contact</h1>
      <p className="text-ink-soft mb-10">
        Questions about a course, a partnership, or just want to say hi? We read every
        message and reply within one business day.
      </p>
      <ContactForm />
    </section>
  );
}
