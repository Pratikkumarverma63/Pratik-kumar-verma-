"use client";

import { useState, Suspense } from "react";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/dashboard";

  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await signIn("credentials", {
      ...form,
      redirect: false,
    });
    setLoading(false);
    if (res?.error) {
      setError("Wrong email or password");
      return;
    }
    router.push(next);
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-sm px-5 pt-16 pb-24">
      <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-3">
        Welcome back
      </p>
      <h1 className="font-display text-3xl mb-8">Log in</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-semibold mb-1.5" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full px-4 py-3 rounded-lg border border-ink/20 bg-paper-raised text-sm focus-ring"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold mb-1.5" htmlFor="password">
            Password
          </label>
          <input
            id="password"
            type="password"
            required
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="w-full px-4 py-3 rounded-lg border border-ink/20 bg-paper-raised text-sm focus-ring"
          />
        </div>

        {error && <p className="text-airmail-red text-sm">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full px-6 py-3.5 rounded-full bg-airmail-red text-paper-raised font-semibold hover:opacity-90 transition-opacity disabled:opacity-60 focus-ring"
        >
          {loading ? "Logging in..." : "Log in"}
        </button>
      </form>

      <p className="text-sm text-ink-soft mt-6">
        New here?{" "}
        <Link href="/signup" className="font-semibold text-ink hover:underline">
          Create an account
        </Link>
      </p>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}
