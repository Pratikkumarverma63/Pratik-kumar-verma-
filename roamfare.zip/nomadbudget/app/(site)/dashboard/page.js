import { redirect } from "next/navigation";
import Link from "next/link";
import { auth } from "@/lib/auth";
import { getEnrollmentsForUser } from "@/lib/queries";

export const metadata = {
  title: "Dashboard",
  robots: { index: false, follow: false },
};

export default async function DashboardPage({ searchParams }) {
  const session = await auth();
  if (!session?.user) redirect("/login?next=/dashboard");

  const { enrolled } = await searchParams;
  const enrollments = getEnrollmentsForUser(session.user.id);

  return (
    <section className="mx-auto max-w-4xl px-5 sm:px-8 pt-14 pb-24">
      <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-3">
        My trips
      </p>
      <h1 className="font-display text-3xl mb-2">Welcome back, {session.user.name}</h1>
      <p className="text-ink-soft mb-10">Everything you&rsquo;ve enrolled in lives here.</p>

      {enrolled && (
        <div className="mb-8 rounded-xl bg-sage/15 border border-sage/30 px-5 py-4 text-sage font-semibold text-sm">
          ✓ You&rsquo;re enrolled! Scroll down to start.
        </div>
      )}

      {enrollments.length === 0 ? (
        <div className="bg-paper-raised border border-ink/10 rounded-2xl p-10 text-center">
          <p className="text-ink-soft mb-5">You haven&rsquo;t enrolled in any courses yet.</p>
          <Link
            href="/courses"
            className="inline-flex px-6 py-3 rounded-full bg-airmail-red text-paper-raised font-semibold hover:opacity-90 transition-opacity"
          >
            Browse courses
          </Link>
        </div>
      ) : (
        <div className="grid gap-4">
          {enrollments.map((e) => (
            <div
              key={e.id}
              className="flex items-center justify-between bg-paper-raised border border-ink/10 rounded-2xl px-6 py-5"
            >
              <div>
                <h2 className="font-display text-lg">{e.title}</h2>
                <p className="text-sm text-ink-soft">{e.tagline}</p>
              </div>
              <Link
                href={`/courses/${e.slug}`}
                className="font-mono text-xs uppercase tracking-wide px-4 py-2 rounded-full border border-ink/20 hover:border-ink/50 transition-colors shrink-0"
              >
                Open
              </Link>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
