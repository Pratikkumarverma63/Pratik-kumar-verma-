import { notFound } from "next/navigation";
import { Check } from "lucide-react";
import AirmailDivider from "@/components/AirmailDivider";
import EnrollButton from "@/components/EnrollButton";
import { getCourseBySlug, getAllCourses, isUserEnrolled } from "@/lib/queries";
import { auth } from "@/lib/auth";

export async function generateStaticParams() {
  return getAllCourses().map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const course = getCourseBySlug(slug);
  if (!course) return {};
  return {
    title: course.title,
    description: course.description,
    alternates: { canonical: `/courses/${course.slug}` },
    openGraph: { title: course.title, description: course.description },
  };
}

function formatPrice(cents, currency) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency.toUpperCase(),
    maximumFractionDigits: 0,
  }).format(cents / 100);
}

export default async function CourseDetailPage({ params }) {
  const { slug } = await params;
  const course = getCourseBySlug(slug);
  if (!course) notFound();

  const session = await auth();
  const alreadyEnrolled = session?.user
    ? Boolean(isUserEnrolled(session.user.id, course.id))
    : false;
  const modules = JSON.parse(course.modules);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Course",
    name: course.title,
    description: course.description,
    provider: { "@type": "Organization", name: "Roamfare" },
    offers: {
      "@type": "Offer",
      price: (course.price_cents / 100).toFixed(2),
      priceCurrency: course.currency.toUpperCase(),
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <section className="mx-auto max-w-6xl px-5 sm:px-8 pt-14 pb-10">
        <div className="grid lg:grid-cols-[1.3fr_1fr] gap-12">
          <div>
            {course.badge && (
              <span className="inline-block font-mono text-[11px] tracking-wide uppercase bg-mustard/25 text-ink px-2 py-1 rounded mb-4">
                {course.badge}
              </span>
            )}
            <h1 className="font-display text-3xl sm:text-4xl mb-3">{course.title}</h1>
            <p className="text-lg text-ink-soft mb-8">{course.tagline}</p>
            <p className="text-ink-soft leading-relaxed mb-10 max-w-2xl">
              {course.description}
            </p>

            <h2 className="font-display text-xl mb-4">What&rsquo;s inside</h2>
            <ul className="space-y-3">
              {modules.map((m, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-sage/20 text-sage shrink-0">
                    <Check size={13} strokeWidth={3} />
                  </span>
                  <span className="text-sm">{m}</span>
                </li>
              ))}
            </ul>
          </div>

          <aside>
            <div className="sticky top-24 bg-paper-raised border border-ink/15 rounded-2xl p-6">
              <div className="flex items-baseline gap-3 mb-1">
                <span className="font-mono text-3xl font-semibold">
                  {formatPrice(course.price_cents, course.currency)}
                </span>
                {course.compare_at_cents && (
                  <span className="font-mono text-sm line-through text-ink-soft">
                    {formatPrice(course.compare_at_cents, course.currency)}
                  </span>
                )}
              </div>
              <p className="text-xs text-ink-soft mb-6">One-time payment · lifetime access</p>
              <EnrollButton slug={course.slug} alreadyEnrolled={alreadyEnrolled} />

              <dl className="mt-6 space-y-2 font-mono text-xs text-ink-soft">
                <div className="flex justify-between">
                  <dt>Runtime</dt>
                  <dd>{course.hours} hours</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Level</dt>
                  <dd>{course.level}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Modules</dt>
                  <dd>{modules.length}</dd>
                </div>
              </dl>
            </div>
          </aside>
        </div>
      </section>
      <AirmailDivider />
    </>
  );
}
