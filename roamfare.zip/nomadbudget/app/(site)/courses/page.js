import BoardingPassCard from "@/components/BoardingPassCard";
import AirmailDivider from "@/components/AirmailDivider";
import { getAllCourses } from "@/lib/queries";

export const metadata = {
  title: "Courses",
  description:
    "Practical courses on points & miles, slow-travel budgeting, and remote work abroad — built for budget travelers and digital nomads.",
  alternates: { canonical: "/courses" },
};

export default function CoursesPage() {
  const courses = getAllCourses();

  return (
    <>
      <section className="mx-auto max-w-6xl px-5 sm:px-8 pt-14 pb-10">
        <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-3">
          All departures
        </p>
        <h1 className="font-display text-3xl sm:text-4xl mb-4">Courses</h1>
        <p className="text-ink-soft max-w-xl">
          Every course is a one-time purchase, lifetime access, no subscription. Pick a
          seat.
        </p>
      </section>
      <AirmailDivider />
      <section className="mx-auto max-w-6xl px-5 sm:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((c) => (
            <BoardingPassCard key={c.id} course={c} />
          ))}
        </div>
      </section>
    </>
  );
}
