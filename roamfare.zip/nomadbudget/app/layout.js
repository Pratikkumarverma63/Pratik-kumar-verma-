import "./globals.css";
import Providers from "@/components/Providers";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://roamfare.example.com";

export const metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Roamfare — Budget Travel & Digital Nomad Courses",
    template: "%s | Roamfare",
  },
  description:
    "Roamfare teaches budget travel and digital nomad skills through practical courses on points & miles, slow-travel budgeting, and remote work abroad.",
  keywords: [
    "budget travel",
    "digital nomad",
    "travel hacking",
    "points and miles",
    "slow travel",
    "remote work abroad",
    "nomad courses",
  ],
  openGraph: {
    title: "Roamfare — Budget Travel & Digital Nomad Courses",
    description:
      "Practical courses and field notes for people who travel on a real budget — not an influencer budget.",
    url: SITE_URL,
    siteName: "Roamfare",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Roamfare — Budget Travel & Digital Nomad Courses",
    description:
      "Practical courses and field notes for people who travel on a real budget — not an influencer budget.",
  },
  alternates: {
    canonical: "/",
  },
};

export default function RootLayout({ children }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Roamfare",
    url: SITE_URL,
    description:
      "Budget travel and digital nomad courses covering points & miles, slow-travel budgeting, and remote work abroad.",
    sameAs: [],
  };

  return (
    <html lang="en">
      <body className="font-body antialiased">
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Providers>
          <Header />
          <main>{children}</main>
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
