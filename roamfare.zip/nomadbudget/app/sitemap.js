import { getAllCourses, getAllPosts } from "@/lib/queries";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://roamfare.example.com";

export default function sitemap() {
  const staticRoutes = ["", "/courses", "/blog", "/contact", "/login", "/signup"].map(
    (route) => ({
      url: `${SITE_URL}${route}`,
      lastModified: new Date(),
    })
  );

  const courseRoutes = getAllCourses().map((c) => ({
    url: `${SITE_URL}/courses/${c.slug}`,
    lastModified: new Date(),
  }));

  const postRoutes = getAllPosts().map((p) => ({
    url: `${SITE_URL}/blog/${p.slug}`,
    lastModified: p.published_at,
  }));

  return [...staticRoutes, ...courseRoutes, ...postRoutes];
}
