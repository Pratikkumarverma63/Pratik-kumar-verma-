import { NextResponse } from "next/server";
import Stripe from "stripe";
import { auth } from "@/lib/auth";
import { getCourseBySlug, isUserEnrolled, createEnrollment } from "@/lib/queries";

export async function POST(request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Please log in first" }, { status: 401 });
  }

  const { slug } = await request.json();
  const course = getCourseBySlug(slug);
  if (!course) {
    return NextResponse.json({ error: "Course not found" }, { status: 404 });
  }

  if (isUserEnrolled(session.user.id, course.id)) {
    return NextResponse.json({ error: "Already enrolled" }, { status: 400 });
  }

  const origin = request.headers.get("origin") || process.env.NEXT_PUBLIC_SITE_URL;

  // Demo mode: no Stripe key configured, so we skip real payment
  // and enroll immediately. Set STRIPE_SECRET_KEY in .env.local
  // to enable real test-mode checkout.
  if (!process.env.STRIPE_SECRET_KEY) {
    createEnrollment({
      userId: session.user.id,
      courseId: course.id,
      stripeSessionId: "demo_mode_no_payment",
    });
    return NextResponse.json({ demo: true, redirect: `/dashboard?enrolled=${course.slug}` });
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

  const checkoutSession = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: course.currency,
          product_data: { name: course.title, description: course.tagline },
          unit_amount: course.price_cents,
        },
        quantity: 1,
      },
    ],
    metadata: { userId: String(session.user.id), courseId: String(course.id) },
    success_url: `${origin}/dashboard?enrolled=${course.slug}`,
    cancel_url: `${origin}/courses/${course.slug}`,
  });

  return NextResponse.json({ url: checkoutSession.url });
}
