import { NextResponse } from "next/server";
import { z } from "zod";
import { saveContactMessage } from "@/lib/queries";

const schema = z.object({
  name: z.string().min(1).max(80),
  email: z.string().email(),
  message: z.string().min(5).max(2000),
});

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid input" },
      { status: 400 }
    );
  }

  saveContactMessage(parsed.data);
  return NextResponse.json({ ok: true });
}
