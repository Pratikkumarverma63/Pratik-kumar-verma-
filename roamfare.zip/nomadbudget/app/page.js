import Link from "next/link";
import { ArrowRight, MapPin } from "lucide-react";
import AirmailDivider from "@/components/AirmailDivider";
import BoardingPassCard from "@/components/BoardingPassCard";
import DepartureStat from "@/components/DepartureStat";
import NewsletterForm from "@/components/NewsletterForm";
import { getAllCourses, getAllPosts } from "@/lib/queries";

export default function HomePage() {
  const courses = getAllCourses().slice(0, 3);
  const posts = getAllPosts().slice(0, 3);

  return (
    <>
      {/* HERO — styled as an oversized boarding pass */}
      <section className="mx-auto max-w-6xl px-5 sm:px-8 pt-14 pb-10">
        <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-10 items-center">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-4">
              Gate open · Boarding · Budget class
            </p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] mb-6">
              See more of the world for less of your paycheck.
            </h1>
            <p className="text-lg text-ink-soft max-w-xl mb-8">
              Roamfare turns points-and-miles tricks, slow-travel budgeting, and
              remote-work logistics into courses you can actually finish — built
              by people who&rsquo;ve done the 14-hour bus rides so you don&rsquo;t
              have to guess.
            </p>
            <div className="flex flex-wrap items-center gap-4">
              <Link
                href="/courses"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-airmail-red text-paper-raised font-semibold hover:opacity-90 transition-opacity focus-ring"
              >
                Browse courses <ArrowRight size={18} />
              </Link>
              <Link
                href="/blog"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-ink/20 font-semibold hover:border-ink/50 transition-colors focus-ring"
              >
                Read the field notes
              </Link>
            </div>
          </div>

          {/* Boarding pass hero graphic */}
          <div className="relative bg-paper-raised border border-ink/15 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-6 flex justify-between items-start">
              <div>
                <p className="font-mono text-[11px] text-ink-soft uppercase tracking-wide">Passenger</p>
                <p className="font-display text-xl">You, Eventually</p>
              </div>
              <MapPin className="text-airmail-red" />
            </div>
            <div className="px-6 pb-6 grid grid-cols-3 gap-4 font-mono">
              <div>
                <p className="text-[11px] text-ink-soft uppercase">From</p>
                <p className="text-2xl font-semibold">HOME</p>
              </div>
              <div className="flex items-center justify-center text-ink-soft">✈</div>
              <div>
                <p className="text-[11px] text-ink-soft uppercase">To</p>
                <p className="text-2xl font-semibold">ANYWHERE</p>
              </div>
            </div>
            <div className="border-t-2 border-dashed border-line mx-6" />
            <div className="p-6 flex justify-between items-center font-mono text-xs text-ink-soft">
              <span>SEAT 12A · WINDOW</span>
              <span>BALANCE: PRICELESS</span>
            </div>
          </div>
        </div>
      </section>

      <AirmailDivider />

      {/* STATS — split-flap departure board */}
      <section className="mx-auto max-w-6xl px-5 sm:px-8 py-14">
        <div className="flex flex-wrap gap-8 sm:gap-14 justify-center sm:justify-start">
          <DepartureStat value="46" label="Countries covered" delay={0} />
          <DepartureStat value="120K" label="Students & readers" delay={120} />
          <DepartureStat value="38" label="Avg. % saved per trip" delay={240} />
          <DepartureStat value="5.5K" label="Points guides indexed" delay={360} />
        </div>
      </section>

      {/* COURSES */}
      <section className="mx-auto max-w-6xl px-5 sm:px-8 py-10">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-2">
              Departures
            </p>
            <h2 className="font-display text-2xl sm:text-3xl">Courses that pay for the next trip</h2>
          </div>
          <Link
            href="/courses"
            className="hidden sm:inline-flex items-center gap-1 text-sm font-semibold text-ink-soft hover:text-ink"
          >
            View all <ArrowRight size={15} />
          </Link>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((c) => (
            <BoardingPassCard key={c.id} course={c} />
          ))}
        </div>
      </section>

      <AirmailDivider />

      {/* BLOG PREVIEW */}
      <section className="mx-auto max-w-6xl px-5 sm:px-8 py-14">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-airmail-blue mb-2">
              Field notes
            </p>
            <h2 className="font-display text-2xl sm:text-3xl">From the road, not the brochure</h2>
          </div>
          <Link
            href="/blog"
            className="hidden sm:inline-flex items-center gap-1 text-sm font-semibold text-ink-soft hover:text-ink"
          >
            View all <ArrowRight size={15} />
          </Link>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {posts.map((p) => (
            <Link
              key={p.id}
              href={`/blog/${p.slug}`}
              className="group block bg-paper-raised border border-ink/10 rounded-2xl p-6 hover:border-ink/30 transition-colors focus-ring"
            >
              <div className="text-3xl mb-4">{p.cover_emoji}</div>
              <p className="font-mono text-[11px] uppercase tracking-wide text-airmail-blue mb-2">
                {p.category} · {p.read_minutes} min read
              </p>
              <h3 className="font-display text-lg leading-snug mb-2 group-hover:underline">
                {p.title}
              </h3>
              <p className="text-sm text-ink-soft line-clamp-3">{p.excerpt}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* NEWSLETTER CTA */}
      <section className="mx-auto max-w-6xl px-5 sm:px-8 pb-20">
        <div className="bg-ink text-paper-raised rounded-3xl p-10 sm:p-14 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl mb-3">
              One email a week. Zero fluff.
            </h2>
            <p className="text-paper-raised/70 max-w-md">
              Fare alerts, one budget trick, and a place worth going — every Thursday.
            </p>
          </div>
          <NewsletterForm />
        </div>
      </section>
    </>
  );
}
