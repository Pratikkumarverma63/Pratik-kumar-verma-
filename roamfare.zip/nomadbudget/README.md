# Roamfare

A full-stack budget-travel / digital-nomad course site: marketing pages, a blog,
authentication, course checkout, and a student dashboard — built with Next.js.

> This is an original site built for you, not a copy of any existing business.
> Brand name, copy, courses, and blog posts are all placeholder content —
> swap them for your own before you launch.

## Stack

- **Framework:** Next.js 16 (App Router)
- **Styling:** Tailwind CSS v4, self-hosted fonts (Archivo Black / IBM Plex Sans / IBM Plex Mono via `@fontsource`)
- **Database:** SQLite via `better-sqlite3` (file-based, zero external services — swap for Postgres later if you outgrow it)
- **Auth:** NextAuth v5, email + password (bcrypt-hashed)
- **Payments:** Stripe Checkout, with a "demo mode" that instantly enrolls users when no Stripe key is configured, so the site works out of the box
- **SEO:** per-page metadata, Open Graph/Twitter cards, JSON-LD (Organization, Course, Article), dynamic `sitemap.xml` and `robots.txt`

## Getting started

```bash
npm install
cp .env.local.example .env.local
```

Open `.env.local` and set at minimum:

```
AUTH_SECRET=<run: openssl rand -base64 32>
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

Then run:

```bash
npm run dev
```

Visit `http://localhost:3000`. The SQLite database is created automatically
at `data/roamfare.db` on first run, seeded with 3 sample courses and 4 blog
posts (see `lib/seed.js`).

## Enabling real payments

By default, clicking "Enroll" on a course instantly grants access with no
real charge (demo mode) — good for testing the whole flow without a Stripe
account.

To take real (or Stripe test-mode) payments:

1. Create a [Stripe](https://dashboard.stripe.com) account and grab your test secret key.
2. Add to `.env.local`:
   ```
   STRIPE_SECRET_KEY=sk_test_...
   ```
3. For production, set up a webhook endpoint pointing at
   `https://yourdomain.com/api/webhook/stripe` listening for
   `checkout.session.completed`, and add the signing secret:
   ```
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```

Without the webhook secret configured, checkout sessions are created but
enrollment won't be confirmed automatically — the webhook is what marks the
purchase complete.

## Project structure

```
app/
  page.js                  Home page
  (site)/courses/          Course listing + detail + checkout
  (site)/blog/             Blog listing + post detail
  (site)/login, /signup    Auth pages
  (site)/dashboard         Logged-in student dashboard
  (site)/contact           Contact form
  api/                     All backend routes (auth, checkout, webhook, contact, newsletter)
  sitemap.js, robots.js    SEO routes
components/                Reusable UI (Header, Footer, cards, forms)
lib/
  db.js                    SQLite connection + schema
  seed.js                  Placeholder seed content — replace with your own
  queries.js               Data access functions
  auth.js                  NextAuth configuration
data/roamfare.db           SQLite database file (git-ignored, auto-created)
```

## Customizing content

- **Courses & blog posts:** edit the arrays in `lib/seed.js`, then delete
  `data/roamfare.db` and restart the dev server to reseed.
- **Brand name / copy:** search for "Roamfare" across `app/` and `components/`.
- **Colors / fonts:** edit the CSS variables in `app/globals.css` (`--paper`,
  `--ink`, `--airmail-red`, `--airmail-blue`, `--mustard`, etc.) and the
  `@theme inline` block.
- **SEO defaults:** `app/layout.js` (site-wide metadata) and each page's
  `export const metadata`.

## Deploying

This app has no external service dependencies beyond Stripe (optional), so
it deploys cleanly to Vercel, Railway, Fly.io, or any Node host that
supports native modules (needed for `better-sqlite3`).

**Note on SQLite in production:** file-based SQLite works well for
low-to-medium traffic on a host with persistent disk (Railway, Fly.io, a VPS).
On platforms with ephemeral/read-only filesystems (e.g. Vercel serverless),
swap in a hosted database — Turso (SQLite-compatible) is the least invasive
migration, or Postgres via Prisma/Drizzle for a larger rebuild.

## Production checklist

- [ ] Replace all placeholder copy, course content, and blog posts
- [ ] Set a real `AUTH_SECRET` and `NEXT_PUBLIC_SITE_URL`
- [ ] Add real Stripe keys and webhook secret
- [ ] Add a real logo/favicon (currently uses a plane icon placeholder)
- [ ] Point `NEXT_PUBLIC_SITE_URL` at your real domain for correct sitemap/OG URLs
- [ ] Consider adding email delivery (e.g. Resend) for the contact form and newsletter signups, which currently just save to the database
