import Link from "next/link";
import AirmailDivider from "./AirmailDivider";
import NewsletterForm from "./NewsletterForm";

export default function Footer() {
  return (
    <footer className="mt-24">
      <AirmailDivider />
      <div className="bg-ink text-paper-raised">
        <div className="mx-auto max-w-6xl px-5 sm:px-8 py-14 grid gap-10 md:grid-cols-[1.3fr_1fr_1fr_1.2fr]">
          <div>
            <p className="font-display text-lg mb-3">ROAMFARE</p>
            <p className="text-sm text-paper-raised/70 max-w-xs">
              Practical courses and field notes for people who travel on a real budget —
              not an influencer budget.
            </p>
          </div>

          <div>
            <p className="font-mono text-xs uppercase tracking-wide text-paper-raised/50 mb-3">
              Explore
            </p>
            <ul className="space-y-2 text-sm">
              <li><Link href="/courses" className="hover:underline">Courses</Link></li>
              <li><Link href="/blog" className="hover:underline">Field Notes</Link></li>
              <li><Link href="/dashboard" className="hover:underline">Dashboard</Link></li>
            </ul>
          </div>

          <div>
            <p className="font-mono text-xs uppercase tracking-wide text-paper-raised/50 mb-3">
              Company
            </p>
            <ul className="space-y-2 text-sm">
              <li><Link href="/contact" className="hover:underline">Contact</Link></li>
              <li><Link href="/login" className="hover:underline">Log in</Link></li>
              <li><Link href="/signup" className="hover:underline">Create account</Link></li>
            </ul>
          </div>

          <div>
            <p className="font-mono text-xs uppercase tracking-wide text-paper-raised/50 mb-3">
              Get the dispatch
            </p>
            <NewsletterForm />
          </div>
        </div>

        <div className="border-t border-paper-raised/10">
          <div className="mx-auto max-w-6xl px-5 sm:px-8 py-5 text-xs text-paper-raised/50 flex flex-col sm:flex-row justify-between gap-2">
            <span>© {new Date().getFullYear()} Roamfare. All rights reserved.</span>
            <span>Built for people who pack light.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
