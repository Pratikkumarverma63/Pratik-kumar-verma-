import Link from "next/link";
import { Clock, BarChart3 } from "lucide-react";

function formatPrice(cents, currency) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency.toUpperCase(),
    maximumFractionDigits: 0,
  }).format(cents / 100);
}

export default function BoardingPassCard({ course }) {
  const code = course.slug.slice(0, 3).toUpperCase();

  return (
    <Link
      href={`/courses/${course.slug}`}
      className="group block focus-ring rounded-2xl"
    >
      <article className="relative flex bg-paper-raised border border-ink/15 rounded-2xl overflow-hidden shadow-[0_1px_0_rgba(0,0,0,0.04)] transition-transform duration-200 group-hover:-translate-y-1">
        {/* Stub */}
        <div className="flex flex-col justify-between p-5 flex-1 min-w-0">
          <div>
            {course.badge && (
              <span className="inline-block font-mono text-[11px] tracking-wide uppercase bg-mustard/25 text-ink px-2 py-1 rounded mb-3">
                {course.badge}
              </span>
            )}
            <h3 className="font-display text-lg leading-snug mb-1">{course.title}</h3>
            <p className="text-ink-soft text-sm">{course.tagline}</p>
          </div>

          <div className="mt-5 flex items-center gap-4 font-mono text-xs text-ink-soft">
            <span className="flex items-center gap-1">
              <Clock size={13} /> {course.hours}h
            </span>
            <span className="flex items-center gap-1">
              <BarChart3 size={13} /> {course.level}
            </span>
          </div>
        </div>

        {/* Perforation */}
        <div className="relative w-0">
          <div className="absolute top-0 bottom-0 left-0 border-l-2 border-dashed border-line" />
          <div className="absolute -top-3 -left-3 w-6 h-6 rounded-full bg-paper" />
          <div className="absolute -bottom-3 -left-3 w-6 h-6 rounded-full bg-paper" />
        </div>

        {/* Ticket end */}
        <div className="flex flex-col items-center justify-center gap-2 bg-ink text-paper-raised px-4 py-5 w-24 shrink-0">
          <span className="font-mono text-[10px] tracking-widest opacity-70 [writing-mode:vertical-rl]">
            {code}-CLASS
          </span>
          <span className="font-mono text-base font-semibold">
            {formatPrice(course.price_cents, course.currency)}
          </span>
          {course.compare_at_cents && (
            <span className="font-mono text-[11px] line-through opacity-50">
              {formatPrice(course.compare_at_cents, course.currency)}
            </span>
          )}
        </div>
      </article>
    </Link>
  );
}
