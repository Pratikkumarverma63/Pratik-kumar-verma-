"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function EnrollButton({ slug, alreadyEnrolled }) {
  const { status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleClick() {
    if (status !== "authenticated") {
      router.push(`/login?next=/courses/${slug}`);
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong");
        setLoading(false);
        return;
      }
      if (data.url) {
        window.location.href = data.url;
      } else if (data.redirect) {
        router.push(data.redirect);
      }
    } catch {
      setError("Network error — try again");
      setLoading(false);
    }
  }

  if (alreadyEnrolled) {
    return (
      <button
        disabled
        className="w-full px-6 py-4 rounded-full bg-sage/20 text-sage font-semibold text-center focus-ring"
      >
        ✓ You&rsquo;re enrolled — go to dashboard
      </button>
    );
  }

  return (
    <div>
      <button
        onClick={handleClick}
        disabled={loading}
        className="w-full px-6 py-4 rounded-full bg-airmail-red text-paper-raised font-semibold hover:opacity-90 transition-opacity disabled:opacity-60 focus-ring"
      >
        {loading ? "Preparing checkout..." : "Enroll now"}
      </button>
      {error && <p className="text-airmail-red text-sm mt-2">{error}</p>}
      <p className="text-xs text-ink-soft mt-3 text-center">
        Secure checkout · Lifetime access · No subscription
      </p>
    </div>
  );
}
