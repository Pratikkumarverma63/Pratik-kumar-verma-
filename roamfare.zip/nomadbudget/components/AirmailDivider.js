export default function AirmailDivider() {
  return <div className="airmail-stripe" role="presentation" />;
}
