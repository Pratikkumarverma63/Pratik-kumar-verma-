export default function DepartureStat({ value, label, delay = 0 }) {
  const chars = String(value).split("");
  return (
    <div className="flex flex-col items-center sm:items-start gap-1">
      <div className="font-mono text-3xl sm:text-4xl font-semibold bg-ink text-paper-raised px-3 py-2 rounded-md flex gap-[1px]">
        {chars.map((c, i) => (
          <span
            key={i}
            className="flap"
            style={{ animationDelay: `${delay + i * 60}ms` }}
          >
            {c}
          </span>
        ))}
      </div>
      <span className="font-mono text-[11px] uppercase tracking-wide text-ink-soft">
        {label}
      </span>
    </div>
  );
}
