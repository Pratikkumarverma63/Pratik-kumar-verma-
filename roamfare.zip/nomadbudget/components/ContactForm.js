"use client";

import { useState } from "react";

export default function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [state, setState] = useState("idle");
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    setState("loading");
    setError("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong");
        setState("idle");
        return;
      }
      setState("done");
    } catch {
      setError("Network error — try again");
      setState("idle");
    }
  }

  if (state === "done") {
    return (
      <div className="bg-sage/15 border border-sage/30 rounded-2xl p-8 text-center">
        <p className="font-display text-lg text-sage mb-1">Message sent ✓</p>
        <p className="text-sm text-ink-soft">We reply within one business day.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-semibold mb-1.5" htmlFor="name">
          Name
        </label>
        <input
          id="name"
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full px-4 py-3 rounded-lg border border-ink/20 bg-paper-raised text-sm focus-ring"
        />
      </div>
      <div>
        <label className="block text-sm font-semibold mb-1.5" htmlFor="email">
          Email
        </label>
        <input
          id="email"
          type="email"
          required
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full px-4 py-3 rounded-lg border border-ink/20 bg-paper-raised text-sm focus-ring"
        />
      </div>
      <div>
        <label className="block text-sm font-semibold mb-1.5" htmlFor="message">
          Message
        </label>
        <textarea
          id="message"
          required
          rows={5}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="w-full px-4 py-3 rounded-lg border border-ink/20 bg-paper-raised text-sm focus-ring resize-none"
        />
      </div>
      {error && <p className="text-airmail-red text-sm">{error}</p>}
      <button
        type="submit"
        disabled={state === "loading"}
        className="px-6 py-3.5 rounded-full bg-airmail-red text-paper-raised font-semibold hover:opacity-90 transition-opacity disabled:opacity-60 focus-ring"
      >
        {state === "loading" ? "Sending..." : "Send message"}
      </button>
    </form>
  );
}
