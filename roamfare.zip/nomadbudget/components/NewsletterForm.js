"use client";

import { useState } from "react";

export default function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState("idle"); // idle | loading | done | error

  async function handleSubmit(e) {
    e.preventDefault();
    setState("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error();
      setState("done");
      setEmail("");
    } catch {
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <p className="font-mono text-sm text-sage font-semibold">
        ✓ You&rsquo;re on the list. First dispatch lands soon.
      </p>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
      <input
        type="email"
        required
        placeholder="you@somewhere-with-wifi.com"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="flex-1 px-4 py-3 rounded-lg border border-ink/20 bg-paper-raised font-body text-sm focus-ring"
      />
      <button
        type="submit"
        disabled={state === "loading"}
        className="px-5 py-3 rounded-lg bg-ink text-paper-raised font-semibold text-sm hover:opacity-90 transition-opacity disabled:opacity-60 focus-ring"
      >
        {state === "loading" ? "Sending..." : "Get the dispatch"}
      </button>
      {state === "error" && (
        <p className="text-airmail-red text-xs sm:hidden">Something went wrong — try again.</p>
      )}
    </form>
  );
}
