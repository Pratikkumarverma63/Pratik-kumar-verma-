"use client";

import Link from "next/link";
import { useState } from "react";
import { useSession, signOut } from "next-auth/react";
import { Menu, X, Plane } from "lucide-react";

const links = [
  { href: "/courses", label: "Courses" },
  { href: "/blog", label: "Field Notes" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const { data: session, status } = useSession();

  return (
    <header className="sticky top-0 z-50 bg-paper/95 backdrop-blur border-b border-line">
      <div className="mx-auto max-w-6xl px-5 sm:px-8 flex items-center justify-between h-16">
        <Link
          href="/"
          className="flex items-center gap-2 font-display text-lg tracking-tight focus-ring rounded"
        >
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-airmail-blue text-paper-raised">
            <Plane size={16} strokeWidth={2.5} />
          </span>
          ROAMFARE
        </Link>

        <nav className="hidden md:flex items-center gap-8 font-medium text-sm">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="text-ink-soft hover:text-ink transition-colors focus-ring rounded"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          {status === "authenticated" ? (
            <>
              <Link
                href="/dashboard"
                className="text-sm font-semibold text-ink-soft hover:text-ink focus-ring rounded"
              >
                Dashboard
              </Link>
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="text-sm font-semibold px-4 py-2 rounded-full border border-ink/15 hover:border-ink/40 transition-colors focus-ring"
              >
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link
                href="/login"
                className="text-sm font-semibold text-ink-soft hover:text-ink focus-ring rounded"
              >
                Log in
              </Link>
              <Link
                href="/signup"
                className="text-sm font-semibold px-4 py-2 rounded-full bg-airmail-red text-paper-raised hover:opacity-90 transition-opacity focus-ring"
              >
                Join free
              </Link>
            </>
          )}
        </div>

        <button
          className="md:hidden focus-ring rounded p-1"
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? "Close menu" : "Open menu"}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-line bg-paper px-5 py-4 flex flex-col gap-4">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="text-ink-soft font-medium"
            >
              {l.label}
            </Link>
          ))}
          <div className="h-px bg-line my-1" />
          {status === "authenticated" ? (
            <>
              <Link href="/dashboard" onClick={() => setOpen(false)} className="font-semibold">
                Dashboard
              </Link>
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="text-left font-semibold text-airmail-red"
              >
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link href="/login" onClick={() => setOpen(false)} className="font-semibold">
                Log in
              </Link>
              <Link
                href="/signup"
                onClick={() => setOpen(false)}
                className="font-semibold text-airmail-red"
              >
                Join free
              </Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}
